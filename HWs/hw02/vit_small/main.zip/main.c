#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <string.h>

#define INTERVALS 5
#define MAX_LIGHT 255
#define MIN_LIGHT 0

const int kernel[3][3] = {
    {  0, -1,  0 },
    { -1,  5, -1 },
    {  0, -1,  0 }
};

void apply_kernel(const unsigned char *input, unsigned char *output, int width, int height) {
    int row_stride = width * 3;
    memcpy(output, input, row_stride);
    
    for (int y = 1; y < height - 1; y++) {
        memcpy(output + y * row_stride, input + y * row_stride, 3);
        
        for (int x = 1; x < width - 1; x++) {
            for (int c = 0; c < 3; c++) {
                int new_value = 0;
                for (int ky = -1; ky <= 1; ky++) {
                    for (int kx = -1; kx <= 1; kx++) {
                        new_value += input[((y + ky) * width + (x + kx)) * 3 + c] * kernel[ky + 1][kx + 1];
                    }
                }
                output[(y * width + x) * 3 + c] = (unsigned char) fmax(MIN_LIGHT, fmin(MAX_LIGHT, new_value));
            }
        }
        memcpy(output + y * row_stride + (width - 1) * 3, input + y * row_stride + (width - 1) * 3, 3);
    }
    memcpy(output + (height - 1) * row_stride, input + (height - 1) * row_stride, row_stride);
}

void compute_histogram(const unsigned char *image, int width, int height, int *histogram) {
    memset(histogram, 0, INTERVALS * sizeof(int));
    
    for (int i = 0; i < width * height; i++) {
        int gray = round(0.2126 * image[i * 3] + 0.7152 * image[i * 3 + 1] + 0.0722 * image[i * 3 + 2]);
        int bin = gray / 51;
        histogram[bin]++;
    }
}

void save_histogram(const int *histogram) {
    FILE *file = fopen("output.txt", "w");
    if (!file) {
        perror("Error opening output.txt");
        exit(1);
    }
    fprintf(file, "%d %d %d %d %d", histogram[0], histogram[1], histogram[2], histogram[3], histogram[4]);
    fclose(file);
}

void process_image(const char *filename) {
    FILE *img_file = fopen(filename, "rb");
    if (!img_file) {
        perror("Error opening file");
        exit(1);
    }

    int width, height;
    if (fscanf(img_file, "P6 %d %d", &width, &height) != 2) {
        exit(100);
    }
    fgetc(img_file);

    unsigned char *input = malloc(width * height * 3);
    unsigned char *output = malloc(width * height * 3);
    int histogram[INTERVALS];

    size_t pixelsRead = fread(input, 1, width * height * 3, img_file);
    if (pixelsRead != (width * height * 3)) {
        exit(102);
    }
    fclose(img_file);

    apply_kernel(input, output, width, height);
    compute_histogram(output, width, height, histogram);
    save_histogram(histogram);

    FILE *output_file = fopen("output.ppm", "wb");
    fprintf(output_file, "P6\n%d %d\n255\n", width, height);
    fwrite(output, 1, width * height * 3, output_file);
    fclose(output_file);

    free(input);
    free(output);
}

int main(int argc, char *argv[]) {
    if (argc != 2) {
        return 1;
    }
    process_image(argv[1]);
    return 0;
}